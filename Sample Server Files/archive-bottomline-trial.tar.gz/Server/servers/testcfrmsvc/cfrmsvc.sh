#!/bin/sh
#chkconfig: 12356 80 25

### BEGIN INIT INFO
# Provides: cfrmsvc
# Required-Start: $ALL
# Should-Start: $network
# Required-Stop:
# Should-Stop: $named $syslog $time
# Default-Start: 1 2 3 5
# Default-Stop: 0 6
# Short-Description: CFRM-Server
# Description: CFRM-Server
# processname: service
### END INIT INFO

startserv(){
	$CMD -t $SERVICE_NAME
	if [ $? -ne 0 ]; then
		echo "The server was not started successfully"
	fi
}

stopserv(){
	$CMD -p $SERVICE_NAME
	if [ $? -ne 0 ]; then
		echo "The server was not stopped successfully"
	fi
}

status(){
	$CMD -a $SERVICE_NAME >/dev/null
	RET=$?
	if [ $RET -lt 0 ]; then
		echo "The server status cannot be querried"
		exit 1
	fi
	case "$RET" in
		"1")
			echo "Server $SERVICE_NAME is not running "
			;;
		"2")
			echo "Server $SERVICE_NAME is stopping "
			;;

		"3")
			echo "Server $SERVICE_NAME is running "
			;;

		"4")
			echo "Server $SERVICE_NAME is starting "
			;;
	esac

}

SCRIPT_HOME=/opt/CFRM/Server/servers/cfrmsvc

cd $SCRIPT_HOME

ETC=`echo $SCRIPT_HOME | grep /etc | wc -l`
if [ $ETC -ne 0 ]; then
	SCRIPT_PATH=`ls -ls $0 | tr -s ' '  | sed -e 's/^ *//' | cut -d ' ' -f12`
	SCRIPT_HOME=`dirname $SCRIPT_PATH`	
	D=`dirname "$SCRIPT_PATH"`
	SCRIPT_HOME="`cd \"$D\" 2>/dev/null && pwd || echo \"$D\"`"

	# /etc/rc3.d	
	ETC=`echo $SCRIPT_HOME | grep "/etc" | wc -l`
	if [ $ETC -ne 0 ]; then
		SCRIPT_PATH=`ls -ls $SCRIPT_PATH | tr -s ' '  | sed -e 's/^ *//' | cut -d ' ' -f12`
		SCRIPT_HOME=`dirname $SCRIPT_PATH`	
	fi
fi

ITX_HOME=$SCRIPT_HOME/../../../
JAVA_HOME="$ITX_HOME/jre"
SERVICE_NAME=`echo $SCRIPT_HOME | sed -e 's/.*\///g'`
cd $ITX_HOME
ITX_HOME=`pwd`


CMD=$ITX_HOME/Server/GXServiceWrapper

cd $ITX_HOME/Server

case "$1" in
	startserv|start)
		startserv
	;;
	stopserv|stop)
		stopserv
	;;
	restart|reload)
		stopserv
		startserv
		RETVAL=$?
	;;
	status)
		status 
		RETVAL=$?
	;;
	*)
		echo
		startserv
esac

exit $RETVAL

